<?
	session_start();
?>
<!DOCTYPE HTML>
<head>
<meta charset = "utf--8">
<title>Information cars</title>
<style>
div { border : 1px solid gray;}
#container{ width:700px;padding:0px;margin:0 auto;}
#header{padding:40px; margin-bottom:15px;}
#contents{width:700px;padding:0px;margin-bottom:0px}
#footer{padding:20px;}

</style>
</head>

<body>
	<div class="images">
	<div id="container">
		<div id="header">
			<? include "../lib/header2.php"; ?>
		</div>
		<div id="contents" align="center">

        			<form  name="member_form" method="post" action="login.php"> 
				<table border="1">		
				<tr><td><img src="../img/title_login.gif"></td></tr>
       				<tr><td><img id="login_msg" src="../img/login_msg.gif"></td></tr>
				<tr><td><img src="../img/id_title.gif"><input type="text" name="id" class="login_input"></td></tr>
				<tr><td><img src="../img/pw_title.gif"><input type="password" name="pass" class="login_input"></td></tr>
				<tr align="center"><td><input type="image" src="../img/login_button.gif"><img src="../img/no_join.gif">&nbsp;&nbsp;&nbsp;&nbsp;<a href="../member/member_form.php"><img src="../img/join_button.gif"></a></td></tr>
				</table>
	    			</form>
			
		</div>	
	</div>
	</div>
</body>
</html>