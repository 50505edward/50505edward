﻿<!DOCTYPE HTML>
<head>
<meta charset = "utf--8">
<title>Information cars</title>
<style>
div { border : 1px solid gray;}
#container{ width:700px;padding:0px;margin:0 auto;}
#header{padding:40px; margin-bottom:15px;}
#contents{width:700px;padding:0px;margin-bottom:0px}
</style>
<script>
   function check_id()
   {
     window.open("check_id.php?id=" + document.member_form.id.value,
         "IDcheck",
          "left=200,top=200,width=200,height=60,scrollbars=no,resizable=yes");
   }

   function check_nick()
   {
     window.open("check_nick.php?nick=" + document.member_form.nick.value,
         "NICKcheck",
          "left=200,top=200,width=200,height=60,scrollbars=no,resizable=yes");
   }

   function check_input()
   {
      if (!document.member_form.id.value)
      {
          alert("아이디를 입력하세요");    
          document.member_form.id.focus();
          return;
      }

      if (!document.member_form.pass.value)
      {
          alert("비밀번호를 입력하세요");    
          document.member_form.pass.focus();
          return;
      }

      if (!document.member_form.pass_confirm.value)
      {
          alert("비밀번호확인을 입력하세요");    
          document.member_form.pass_confirm.focus();
          return;
      }

      if (!document.member_form.name.value)
      {
          alert("이름을 입력하세요");    
          document.member_form.name.focus();
          return;
      }

      if (!document.member_form.nick.value)
      {
          alert("닉네임을 입력하세요");    
          document.member_form.nick.focus();
          return;
      }


      if (!document.member_form.hp2.value || !document.member_form.hp3.value )
      {
          alert("휴대폰 번호를 입력하세요");    
          document.member_form.nick.focus();
          return;
      }

      if (document.member_form.pass.value != 
            document.member_form.pass_confirm.value)
      {
          alert("비밀번호가 일치하지 않습니다.\n다시 입력해주세요.");    
          document.member_form.pass.focus();
          document.member_form.pass.select();
          return;
      }

      document.member_form.submit();
   }

   function reset_form()
   {
      document.member_form.id.value = "";
      document.member_form.pass.value = "";
      document.member_form.pass_confirm.value = "";
      document.member_form.name.value = "";
      document.member_form.nick.value = "";
      document.member_form.hp1.value = "010";
      document.member_form.hp2.value = "";
      document.member_form.hp3.value = "";
      document.member_form.email1.value = "";
      document.member_form.email2.value = "";
	  
      document.member_form.id.focus();

      return;
   }
</script>
</head>

<body>  
	<div id="container">
 		<div id="header">
    			<? include "../lib/header2.php"; ?>
 		</div>  <!-- end of header -->

  		<div id="content" align="center">
        	<form  name="member_form" method="post" action="insert.php"> 
		<table border="1">
			<tr><td  colspan="2"><img src="../img/title_join.gif"></td></tr>
			<tr><td>* 아이디</td><td><div id="id1"><input type="text" name="id"></div><div id="id2"><a href="#"><img src="../img/check_id.gif" onclick="check_id()"></a></div><div id="id3">4~12자의 영문 소문자, 숫자와 특수기호(_) 만 사용할 수 있습니다.</div></td></tr>		
			<tr><td>* 비밀번호</td><td><input type="password" name="pass"></td></tr>
			<tr><td>* 비밀번호 확인</td><td><input type="password" name="pass_confirm"></td></tr>
			<tr><td>* 이름</td><td><input type="text" name="name"></td></tr>
			<tr><td>* 닉네임</td><td><div id="nick1"><input type="text" name="nick"></div><div id="nick2" ><a href="#"><img src="../img/check_id.gif" onclick="check_nick()"></a></div></td></tr>
			<tr><td>* 휴대폰</td><td><select class="hp" name="hp1"> 
              <option value='010'>010</option>
              <option value='011'>011</option>
              <option value='016'>016</option>
              <option value='017'>017</option>
              <option value='018'>018</option>
              <option value='019'>019</option>
              </select>  - <input type="text" class="hp" name="hp2"> - <input type="text" class="hp" name="hp3"></tr>
			<tr><td>&nbsp;&nbsp;이메일</td><td><input type="text" id="email1" name="email1"> @ <input type="text" name="email2"></td></tr>
			<tr><td colspan="2" align="center">* 는 필수 입력 항목입니다.</td></tr>
			<tr><td colspan="2" align="center"><a href="#"><img src="../img/button_save.gif"  onclick="check_input()"></a>&nbsp;&nbsp;
		                 <a href="#"><img src="../img/button_reset.gif" onclick="reset_form()"></a></td></tr>
		</table>
		</form>
		</div>
	</div> 

</body>
</html>
