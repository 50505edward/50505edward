<a href="../inform.php"><h1>Information cars</h1></a>
<?
    if(!$userid)
	{
?>
          <a href="../login/login_form.php"><img src="../img/member01.gif"></a>  <a href="./member/member_form.php"><img src="../img/member02.gif"></a>
<?
	}
	else
	{
?>
		<?=$usernick?> (level:<?=$userlevel?>) | 
		<a href="../login/logout.php">�α׾ƿ�</a> | <a href="../login/member_form_modify.php">��������</a>
<?
	}
?>

