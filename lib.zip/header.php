<a href="./inform.php"><h1>Information cars</h1></a>
<?session_start();?>

<?
    if(!$_SESSION['userid'])
	{
?>
          <a href="./login/login_form.php"><img src="./img/member01.gif"></a>  <a href="./member/member_form.php"><img src="./img/member02.gif"></a>
<?
	}
	else
	{
?>
		<a href="./login/logout.php">�α׾ƿ�</a> | <a href="./login/member_form_modify.php">��������</a>
<?
	}
?>

